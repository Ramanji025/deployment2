"use strict";
var express = require('express'),
    bodyParser = require('body-parser'),
    app = express(),
    inContainer = process.env.CONTAINER;
var cors = require('cors')
const api = require('./api/rest')
app.set('port', (process.env.PORT || 3000))

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/api', api);

//CORS
app.use(cors());

//The dist folder has our static resources (index.html, css, images)
if (!inContainer) {
    app.use(express.static(__dirname + '/dist'));
}


// redirect all others to the index (HTML5 history)
app.all('/*', function (req, res) {
    res.sendFile(__dirname + '/dist/index.html');
});

//app.listen(3000);

const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/mydb', { useNewUrlParser: true });
const db = mongoose.connection
db.on('error', console.error.bind(console, 'connection error:'))
db.once('open', function () {
	console.log('Connected to MongoDB')

	app.listen(app.get('port'), function () {
		console.log('API Server Listening on port ' + app.get('port') + '!')
	})
})
