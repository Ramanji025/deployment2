const companyService = require('../../service/companyService');
const messages = require('../../data/messages');

module.exports = function(router){
    router.get('/company', (req, res, next) => {
            companyService.getCompany().then(result => {
                res.json(result);
            }).catch(err => {
                res.status(500).send(messages.Failed());
            });
        
        });
}