const itemMasterService = require('../../service/itemMasterService');
const messages = require('../../data/messages'); 

module.exports = function(router){
   
    router.get('/item', (req, res, next) => {

            itemMasterService.getItems().then(result =>{
                res.status(200).json(result);
            }).catch(err => {
                res.status(500).send(messages.Failed());
            });
        });
        
        router.get('/item/byCode/:code', (req, res, next) => {
            console.log("Inside Item By Id")
            itemMasterService.getItemsByCode(req.params.code).then(result =>{
                res.status(200).json(result);
                console.log("Inside Item By Id")
            }).catch(err => {
                res.status(500).send(messages.Failed());
            });
        });
        
        
        router.post('/item', (req, res, next) => {
            
            itemMasterService.saveItem(req.body).then(result =>{
                res.status(200).json(messages.Success());
            }).catch(err => {
                res.status(500).json(messages.Failed());
            });
        });
        
        router.patch('/item', (req, res, next) => {
            
            itemMasterService.updateItem(req.body).then( result =>{
                res.status(200).send(messages.Success());
            }).catch(err => {
                res.status(500).send(messages.Failed());
            });
        });
        
}