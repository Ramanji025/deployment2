const goodsItemService = require('../../service/goodsItemService');
const itemService = require('../../service/itemMasterService');
const messages = require('../../data/messages');
const goodsService = require('../../service/goodsReceiptService');

module.exports = function (router) {

  router.get('/goods/item', (req, res, next) => {

    try {
     itemService.getItems().then(function (result) {
          var items = result;
          goodsItemService.getGoodsItems().then(function (resul) {
            var data = [];
            resul.forEach(ele => {
              var item = items.filter(function (els) {
                return els.itemId === ele.itemNo;
              })
              if (item.length !== 0) {
                ele.itemNo = item[0].itemName;
              }
              data.push(ele);
            });
            res.json(data);
          });
        });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });

  router.get('/goods/itemRaw', (req, res, next) => {

    try {
      goodsItemService.getGoodsItems().then(function (resul) {
        res.json(resul);
      });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });


  router.get('/goods/item/:resNo', (req, res, next) => {

    try {
      itemService.getItems().then(function (result) {
        var items = result;
        goodsItemService.getGoodsItemsByResNo(req.params.resNo).then(function (resul) {
          var data = [];
          resul.forEach(ele => {
            var item = items.filter(function (els) {
              return els.itemId === ele.itemNo;
            })
            if (item.length !== 0) {
              ele.itemNo = item[0].itemName;
            }
            data.push(ele);
          });
          res.json(data);
        });
      });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });

  router.get('/goods/stock/report/:fromDate/:toDate', (req, res, next) => {

    try {
      goodsItemService.getGoodsItemsBetweenDates(req.params.fromDate, req.params.toDate).then(function (resul) {
        itemService.getItems().then(function (result) {
          var data = [];
          result.forEach(item => {
            var sale = 0;
            var saleRejected = 0;
            var purchase = 0;
            var purchaseRejected = 0;
            var filterData = resul.filter(f => {
              return f.itemNo === item.itemId;
            });
            if (filterData !== 0) {
              filterData.forEach(filterEle => {

                if (filterEle.type === 'SALE') {
                  sale += parseInt(filterEle.quantity.toString());
                  if (filterEle.rejectedQty != null) {
                    saleRejected += parseInt(filterEle.rejectedQty.toString());
                  }
                }
                if (filterEle.type === 'PURCHASE') {
                  purchase += parseInt(filterEle.quantity.toString());
                  if (filterEle.rejectedQty != null) {
                    purchaseRejected += parseInt(filterEle.rejectedQty.toString());
                  }
                }
              });
              var itemDec = {
                itemNo: item.itemId,
                itemName: item.itemName,
                price: item.price,
                available: item.quantity,
                purchaseRejected: purchaseRejected,
                purchased: purchase,
                saleRejected: saleRejected,
                sold: sale
              };
              data.push(itemDec);
            }
          });
          res.json(data);
        });
      });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });

  router.get('/goods/stock/report/pie', (req, res, next) => {

    try {
      goodsItemService.getGoodsItems().then(function (resul) {
        itemService.getItems().then(function (result) {
          var data = [];
          var sales = 0;
          var salesRejected = 0;
          var purchases = 0;
          var purchasesRejected = 0;
          result.forEach(item => {
            var sale = 0;
            var saleRejected = 0;
            var purchase = 0;
            var purchaseRejected = 0;
            var filterData = resul.filter(f => {
              return f.itemNo === item.itemId;
            });
            if (filterData !== 0) {
              filterData.forEach(filterEle => {

                if (filterEle.type === 'SALE') {
                  sale += parseInt(filterEle.quantity.toString());
                  if (filterEle.rejectedQty != null) {
                    saleRejected += parseInt(filterEle.rejectedQty.toString());
                  }
                }
                if (filterEle.type === 'PURCHASE') {
                  purchase += parseInt(filterEle.quantity.toString());
                  if (filterEle.rejectedQty != null) {
                    purchaseRejected += parseInt(filterEle.rejectedQty.toString());
                  }
                }
              });
              sales += parseInt(sale);
              purchases += parseInt(purchase);
              salesRejected += parseInt(saleRejected);
              purchasesRejected += parseInt(purchaseRejected);
            }
          });
          data = [sales, purchases, salesRejected, purchasesRejected];
          res.json(data);
        });
      });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });


  router.get('/goods/item/raw/:resNo', (req, res, next) => {

    try {
      goodsItemService.getGoodsItemsByResNo(req.params.resNo).then(function (resul) {

        res.json(resul);
      });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });

  router.get('/goods/item/monthly/data', (req, res, next) => {

    try {
      goodsItemService.getGoodsByMonth().then(function (resul) {

        res.json(resul);
      });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });

  router.get('/goods/item/data/:itemIdOrId', (req, res, next) => {
    console.log('/goods/itemsBy/itemIdOrId ***** Start');
    try {
      goodsItemService.getGoodsByItemIdOrId(req.params.itemIdOrId).then(function (resul) {
        console.log('/goods/itemsBy/itemIdOrId ***** End');
        res.json(resul);
      });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });


  router.post('/goods/item', (req, res, next) => {
    try {
      goodsItemService.saveGoodsItems(req.body);
    } catch (error) {
      res.status(500).json(messages.Failed());
    }

    res.status(200).json(messages.Success());

  });

  router.patch('/goods/item', (req, res, next) => {
    try {
      goodsItemService.updateGoodsItem(req.body).then(response => {
        res.status(200).json(messages.Success());
      });

    } catch (error) {

      res.status(500).json(messages.Failed());
    }

  });

  router.delete('/goods/item/:id', (req, res, next) => {
    try {
      goodsItemService.deleteItemByItemId(req.params.id)
        .then(response => {
          res.status(200).json(messages.Success());
        });

    } catch (error) {

      res.status(500).json(messages.Failed());
    }
  });

  router.delete('/goods/item/byResNo/:resNo', (req, res, next) => {
    try {
      goodsItemService.deleteItemByResNo(req.params.resNo)
        .then(response => {
          res.status(200).json(messages.Success());
        });

    } catch (error) {

      res.status(500).json(messages.Failed());
    }
  });

}
