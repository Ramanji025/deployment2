const groupService = require('../../service/groupService');
const messages = require('../../data/messages'); 

module.exports = function (router) {

    router.get('/groups', (req, res, next) => {
        
        groupService.getGroups().then(result => {
            res.status(200).json(result);
        }).catch(err =>{
            res.status(500).send(messages.Failed());
        });

    });

    router.post('/groups', (req, res, next) => {
        groupService.saveGroup(req.body).then(result => {
            res.status(200).send(messages.Success());
        }).catch(err => {
            res.status(500).send(messages.Failed());
        });
    });

    router.patch('/groups', (req, res, next) => {
        
        groupService.updateGroup(req.body).then(result => {
            res.status(200).send(messages.Success());
        }).catch(err =>{
            res.status(500).send(messages.Failed());
        });
        
    });
}