const GoodsSales = require('../models/salesModel');

module.exports = {
    async getGoodsSales(){
        const result = 
        await GoodsSales.find({'active':'Y'},null,{sort: {'invoiceDate': -1}},function(err, data){
            return data;
        });

        return result;
    },

    async getGoodsSalesCountByDate(){
        
        var d = new Date();
        d.setDate(d.getDate() - 1);
        const result = await GoodsSales.find({'active':'Y', 'invoiceDate':{$gt :d}},function(err,data){
            return data;
        });
        return result;
        },
    async getGoodsSalesByResNo(resNo){
        const result = 
        await GoodsSales.
            find({'active':'Y','resNo':resNo},
            function(err, data){
            
            return data;
        });

        return result;
    },

    saveGoodsSales: async function(data){
        var receipt = new GoodsSales(data);
       const result = await 
            receipt.save(function(err){
            if(err) console.log(err);
        });

        return result;
    },
    updateGoodsSales : async function(data){
        const result = await GoodsSales.
                        findOneAndUpdate({resNo:data.resNo},
                        data,function(err){
            if(err){
               console.log(err); 
            }
        });
        return result;
    },
    deleteGoodsSaleById: async function(id){
        const result = await GoodsSales.findByIdAndDelete({_id:id} ,function(err){
            if(err){
                console.log(err);
            }
        });

        return result;
    }

    

}