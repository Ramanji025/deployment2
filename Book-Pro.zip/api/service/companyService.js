const Company = require('../models/companyModel');

module.exports = {
async getCompany(){
    const result = await Company.find({},function(err,data){
        
        return data;
    }); 
    return result;
}

}