const GoodsItem = require('../models/goodsItemModel');

module.exports = {

    async getGoodsItems(){
        const result =
        await GoodsItem.find({'active':'Y'},function(err, data){
            return data;
        });

        return result;
    },
  async getGoodsItemsBetweenDates(from, to){
    const result =
      await GoodsItem.find({ 'date':{$gte :from, $lte :to} , 'active':'Y'},function(err, data){
        return data;
      });

    return result;
  },

    async getGoodsByMonth(){
        var date =  new Date();
        var day = date.getDate()+1;
        var final = new Date(date.getFullYear(),date.getMonth()+1, -day);
        const result = await GoodsItem.find({'active':'Y', 'date':{$gte :final}},function(err,data){
            return data;
        });
        return result;
    },

    async getGoodsByItemIdOrId(itemId){
        const result = await GoodsItem.find({'active':'Y','itemNo':itemId},function(err,data){
            return data;
        });
        return result;
    },

    async getGoodsItemsByResNo(resNo){
        const result =
        await GoodsItem.find({'active':'Y', 'resNo':resNo},function(err, data){
            return data;
        });

        return result;
    },

    saveGoodsItems: async function(data){
        var goodsRes = new GoodsItem(data);
       const result = await goodsRes.save(function(err){
            if(err) throw err;
        });

        return result;
    },
    updateGoodsItem : async function(data){
        const result = await GoodsItem.
                        findByIdAndUpdate({_id:data._id},data,function(err){
            if(err){
               console.log(err);
            }
        });
        return result;
    },
    deleteItemByItemId: async function(id){
        const result = await GoodsItem.findByIdAndDelete({_id:id} ,function(err){
            if(err){
                console.log(err);
            }
        });

        return result;
    },
    deleteItemByResNo: async function(resNo){
        const result = await GoodsItem.deleteMany({'resNo':resNo} ,function(err){
            if(err){
                console.log(err);
            }
        });

        return result;
    }
}
