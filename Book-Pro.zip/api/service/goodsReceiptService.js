const GoodsReceipt = require('../models/goodsReceiptModel');

module.exports = {
  async getGoodsReceipt() {
    const result =
      await GoodsReceipt.find({'active': 'Y'}, null, {sort: {'invoiceDate': -1}}, function (err, data) {
        return data;
      });

    return result;
  },
  async getGoodsReceiptByResNo(resNo) {
    const result =
      await GoodsReceipt.find({'active': 'Y', 'resNo': resNo}, null, {sort: {'invoiceDate': -1}}, function (err, data) {

        return data;
      });

    return result;
  },

  async getGoodsReceiptCountByDate() {
    var d = new Date();
    d.setDate(d.getDate() - 1);
    const result = await GoodsReceipt.find({'active': 'Y', 'invoiceDate': {$gt: d}}, function (err, data) {
      return data;
    });
    return result;
  },

  saveGoodsReceipt: async function (data) {
    var receipt = new GoodsReceipt(data);
    const result = await receipt.save(function (err) {
      if (err) throw err;
    });

    return result;
  },
  updateGoodsReceipt: async function (data) {
    const result = await GoodsReceipt.findOneAndUpdate({resNo: data.resNo}, data, function (err) {
      if (err) {
        console.log(err);
      }
    });
    return result;
  },
  deleteGoodsReceiptById: async function (id) {
    const result = await GoodsReceipt.findByIdAndDelete({_id: id}, function (err) {
      if (err) {
        console.log(err);
      }
    });

    return result;
  }
}
