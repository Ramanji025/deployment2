const mongoose = require('mongoose');

const ItemMasterSchema = new mongoose.Schema({
    itemId:'string',
    itemName: 'string',
    date: 'string',
    quantity: 'number',
    price: 'number',
  salePrice: 'number',
    year: 'string',
    location: 'string',
    description: 'string',
    active: {type:'string',default:'Y'},
});

module.exports = mongoose.model('ItemMaster',ItemMasterSchema)
