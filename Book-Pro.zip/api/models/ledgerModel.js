const mongoose = require('mongoose');


const LedgerSchema = new mongoose.Schema({
    code: 'string',
    ledgerName: 'string',
    group: 'string',
    opening: 'number',
    oType: 'string',
    date: {type: 'date', default: new Date()},
    mobile: 'number',
    town: 'string',
    offAddress: 'string',
    billAddress: 'string',
    bankName: 'string',
    bankCity: 'string',
    bName: 'string',
    accNumber: 'string',
    ifsc: 'string',
    active: {type:'string',default:'Y'},
});

module.exports = mongoose.model('Ledger',LedgerSchema);
