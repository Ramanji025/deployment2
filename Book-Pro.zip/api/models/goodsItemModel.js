const mongoose = require('mongoose');

const GoodsItemsSchema = new mongoose.Schema({
    resNo: 'string',
    itemNo: 'string',
    quantity: 'string',
    cost: 'number',
    rejectedQty: 'number',
    rejectedReason: 'string',
    amount: 'number',
    date: {type: 'date', default: new Date()},
    igstAmount: 'number',
    sgstAmount: 'number',
    cgstAmount: 'number',
    totalTaxAmount: 'number',
    type: 'string',
    active: {type:'string',default:'Y'},   
});

module.exports = mongoose.model('GoodsItem',GoodsItemsSchema);