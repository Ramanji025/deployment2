
module.exports = {

  Success : function(){
    return {"code": 100,"status": "Success"};
  },
  Failed : function(){
    return {"code": 101,"status": "Failed"};
  }
  
}
  