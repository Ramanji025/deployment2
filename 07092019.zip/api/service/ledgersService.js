const Ledger = require('../models/ledgerModel');

module.exports = {
    
    async getLedgers(callback){
        const result = await Ledger.find({'active':'Y'},function(err,data){
            
            return data;
        }); 
          return result;
    },

    async getLedgerById(id){
        const result = await Ledger.find({active:'Y',_id:id},function(err,data){
            return data;
        }); 
          return result;
    },

    async getLedgerByLedgerId(id){
        const result = await Ledger.find({active:'Y',code:id},function(err,data){
            return data;
        }); 
          return result;
    },
    
    async getLedgerByGroupId(groupName){
        const result = await Ledger.find({active:'Y',group:groupName},function(err,data){
            return data;
        }); 
          return result;
    },

    saveLedger : async function(data){
        var ledger = new Ledger(data);
        const result = await ledger.save(function(err){
            if(err) throw err;
        });
        return result;
    },

    updateLedger : async function(data){
        const result = await Ledger.findByIdAndUpdate({_id:data._id},data,function(err){
            if(err){
               console.log(err); 
            }
        });
        return result;
    }
}
