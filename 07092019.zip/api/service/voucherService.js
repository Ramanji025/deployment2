const Voucher = require('../models/voucherModel');
const  moment = require('moment');

module.exports = {

  async getVourcherByVTypeAndVMode(vType) {

    const result =
      await Voucher.find({'vType': vType, 'active': 'Y'}, null,
        {sort: {'date': -1}}, function (err, data) {
          return data;
        });

    return result;
  },
  async getVourcherByResNo(resNo) {

    const result =
      await Voucher.find({'resNo': resNo, 'active': 'Y'}, null,
        {sort: {'date': -1}}, function (err, data) {
          return data;
        });

    return result;
  },

  async getVourcherById(Id) {

    const result =
      await Voucher.findOne({_id: Id, 'active': 'Y'}, null,
        {sort: {'date': -1}}, function (err, data) {
          return data;
        });

    return result;
  },

  async getVourcherBetweenDates(ledgerId, fromDate, toDate) {
    const result =
      await Voucher.find({ $or:[{'receiver':ledgerId},{'sender':ledgerId}],
          'active': 'Y', 'date': { $lte: toDate, $gte: fromDate}},
      null, {sort: {'date': -1}}, function (err, data) {
      return data;
    });
    return result;
  },

  saveVoucher: async function (data) {
    var voucher = new Voucher(data);
    const result = await voucher.save(function (err) {
      if (err) throw err;
    });

    return result;
  },
  updateVoucher: async function (data) {

    const result = await Voucher.findByIdAndUpdate({_id: data._id}, data).then(response => {
      return response;
    }).catch(err => {

    })

    return result;
  },
  updateVoucherByResNo: async function (data) {
    const result = await Voucher.findOneAndUpdate({'resNo': data.resNo}, data, function (err) {
      if (err) {
        console.log(err);
      }
    });
    return result;
  },

  deleteVoucherByResNo: async function (resNo) {
    const result = await Voucher.findOneAndDelete({'resNo': resNo}, function (err) {
      if (err) {
        console.log(err);
      }
    });
    return result;
  }


}
