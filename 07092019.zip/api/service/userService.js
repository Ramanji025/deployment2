
const User = require('../models/userModel');

module.exports ={

    userAuth : async function(uname,password){
        const result = await User.find({'userName':uname,'password':password,'active':'Y'}, function(err,user1){
            return user1;
        });
        return result;
    },
    async getUsers(callback){
        const result = await User.find({'active':'Y'},function(err,data){
            return data;
        }); 
          return result;
    },
    saveUsers : async function(data){
        var user = new User(data);
        const result = await user.save(function(err){
            if(err) throw err;
        });
        return result;
    },
    updateUser : async function(data){
        const result = await User.findByIdAndUpdate({_id:data._id},data,function(err){
            if(err){
                console.log(err);
            }
        });
        return result;
    }
}