const Group = require('../models/groupsModel');

module.exports ={

    async getGroups(){
        const result = await Group.find({'active':'Y'},function(err,data){
            return data;
        });
          return result;
    },

  async getGroupsByName(name){
    const result = await Group.find({'active':'Y','groupName':name},function(err,data){
      return data;
    });
    return result;
  },

    async getGroups(id){
        const result = await Group.find({'active':'Y'},function(err,data){
            return data;
        });
          return result;
    },

    async getGroupByCode(id){
        const result = await Group.find({'active':'Y'},{'code':id},function(err,data){
            return data;
        });
          return result;
    },

    saveGroup : async function(data){
        var group = new Group(data);
        const result = await group.save(function(err){
            if(err) throw err;
        });
        return result;
    },

    updateGroup : async function(data){
        const result = await Group.findByIdAndUpdate({_id:data._id},data,function(err){
            if(err){
                next();
            }
        });
        return result;
    },

}
