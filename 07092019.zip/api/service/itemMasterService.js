const ItemMaster = require('../models/itemMasterModel');

module.exports = {
    async getItems(){
        const result = 
        await ItemMaster.find({'active':'Y'},null, {sort: {'date': -1}},function(err, data){
            return data;
        });

        return result;
    },

    async getItemsByCode(code){
        const result = 
        await ItemMaster.find({'active':'Y',$or:[{'itemName':code},{'itemId':code}]},
        null, {sort: {'date': -1}},function(err, data){
            return data;
        });

        return result;
    },
    saveItem: async function(data){
        var item = new ItemMaster(data);
       const result = await item.save(function(err){
            if(err) console.log(err);
        });

        return result;
    },
    updateItem : async function(data){
        console.log('update item master');
        const result = await ItemMaster.findByIdAndUpdate({_id:data._id},data,function(err){
            if(err){
               console.log(err); 
            }
        });
        return result;
    }
}