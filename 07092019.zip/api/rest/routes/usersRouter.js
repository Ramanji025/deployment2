const userService = require('../../service/userService');
const messages = require('../../data/messages'); 

module.exports = function(router){

    router.get('/users', (req, res, next) => {
        userService.getUsers().then(result => {
            res.status(200).json(result);
        }).catch(err =>{
            res.status(500).json(messages.Failed());
        });
    
    });
    
    router.get('/users/auth/:uname/:password', (req, res, next) => {
        userService.userAuth(req.params.uname, req.params.password).then(result => {
            if (result.length === 0) {
                res.status(401).send(messages.Failed());
            } else {
                res.status(200).send(messages.Success());
            }
    
        }).catch(err => res.status(500).send(err));
    
    });
    
    router.post('/users', (req, res, next) => {
      
        userService.saveUsers(req.body).then(result =>{
            res.status(200).send(messages.Success());
        }).catch(err =>{
            res.status(500).send(messages.Failed());
        });
    
    });
    
    router.patch('/users', (req, res, next) => {
        
        userService.updateUser(req.body).then(result =>{
            res.status(200).send(messages.Success());
        }).catch(err =>{
            res.status(500).send(messages.Failed());
        });
         
    });


}