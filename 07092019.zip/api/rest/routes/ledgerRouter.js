const ledgerService = require('../../service/ledgersService');
const messages = require('../../data/messages'); 

module.exports = function(router){

    router.get('/ledgers', (req, res, next) => {

        ledgerService.getLedgers().then(function (result) {
            res.send(result);
        });
    
    });
    
    router.get('/ledgers/:id', (req, res, next) => {
        ledgerService.getLedgerById(req.params.id).then(function (result) {
            res.send(result);
        });
    
    });

    router.get('/ledgers/byLId/:id', (req, res, next) => {
        ledgerService.getLedgerByLedgerId(req.params.id).then(function (result) {
            res.send(result);
        });
    
    });
    
    router.get('/ledgers/ledgersByGroupId/:id', (req, res, next) => {
    
        ledgerService.getLedgerByGroupId(req.params.id).then(function (result) {
            res.send(result);
        });
    
    });
    
    router.post('/ledgers', (req, res, next) => {
    
        try {
            ledgerService.saveLedger(req.body);
        } catch (error) {
            res.status(500).send(messages.Failed());
        }
    
        res.status(200).send(messages.Success());
    
    });
    
    router.patch('/ledgers', (req, res, next) => {
        try {
            ledgerService.updateLedger(req.body);
        } catch (error) {
            res.status(500).send(messages.Failed());
        }
    
        res.status(200).send(messages.Success());
    
    });
}

