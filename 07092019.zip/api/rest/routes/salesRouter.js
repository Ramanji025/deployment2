const goodsSalesService = require('../../service/salesService');
const ledgerService = require('../../service/ledgersService');
const messages = require('../../data/messages');

module.exports = function (router) {

    router.get('/goods/sales', (req, res, next) => {
        console.log("/goods/sales ***** Start");
        ledgerService.getLedgers().then(function (result) {
            var ledger = result;
            goodsSalesService.getGoodsSales().then(function (goodsRes) {
                var data = [];
                goodsRes.forEach(ele => {
                    var sender = ledger.filter(function (els) {
                        return els.code === ele.vendor;
                    })

                    if (sender.length !== 0) {
                        ele.vendor = sender[0].ledgerName;
                    }

                    data.push(ele);
                })

                console.log("/goods/sales ***** Exit")
                res.json(data);
            });

        });
    });

  router.get('/goods/sales/byFromAndTo/:from/:to', (req, res, next) => {
    console.log("/goods/sales/byFromAndTo ***** Start");
    ledgerService.getLedgers().then(function (result) {
      var ledger = result;
      goodsSalesService.getGoodsSalesByFromAndTo(req.params.from,req.params.to).then(function (goodsRes) {
        var data = [];
        goodsRes.forEach(ele => {
          var sender = ledger.filter(function (els) {
            return els.code === ele.vendor;
          })

          if (sender.length !== 0) {
            ele.vendor = sender[0].ledgerName;
          }

          data.push(ele);
        })

        console.log("/goods/sales/byFromAndTo ***** Exit")
        res.json(data);
      });

    });
  });


    router.get('/goods/sales/:resNo', (req, res, next) => {
        console.log("/goods/sales ***** Start");
        ledgerService.getLedgers().then(function (result) {
            var ledger = result;
            goodsSalesService.getGoodsSalesByResNo(req.params.resNo).then(function (goodsRes) {
                var data = [];
                goodsRes.forEach(ele => {
                    var sender = ledger.filter(function (els) {
                        return els.code === ele.vendor;
                    })

                    if (sender.length !== 0) {
                        ele.vendor = sender[0].ledgerName;
                    }

                    data.push(ele);
                })

                console.log("/goods/receipt ***** Exit")
                res.json(data);
            });

        });
    });

    router.get('/goods/sales/raw/:resNo', (req, res, next) => {
        console.log("/goods/sales/raw ***** Start");

        goodsSalesService.getGoodsSalesByResNo(req.params.resNo).then(function (goodsRes) {

            console.log("/goods/sales/raw ***** Exit")
            res.json(goodsRes);
        });
    });

    router.get('/goods/sales/byDate/today', (req, res, next) => {

        console.log("/goods/sales/raw ***** Start");
        goodsSalesService.getGoodsSalesCountByDate().then(function (goodsRes) {
        console.log("/goods/sales/raw ***** Exit")
            res.json(goodsRes);
        });
    });


  router.get('/goods/sales/print/:resNo', (req, res, next) => {
    console.log("/goods/sales/raw ***** Start");
   res.status(200).send(messages.Success());
  });

router.post('/goods/sales', (req, res, next) => {
    try {
        goodsSalesService.saveGoodsSales(req.body);
    } catch (error) {
        res.status(500).send(messages.Failed());
    }

    res.status(200).send(messages.Success());

});

router.patch('/goods/sales', (req, res, next) => {
    try {
        goodsSalesService.updateGoodsSales(req.body);
    } catch (error) {
        res.status(500).send(messages.Failed());
    }
    res.status(200).send(messages.Success());

});

router.delete('/goods/sales/:id', (req, res, next) => {
    try {
        goodsSalesService.deleteGoodsSaleById(req.params.id);
    } catch (error) {
        res.status(500).send(messages.Failed());
    }
    res.status(200).send(messages.Success());

});

}
