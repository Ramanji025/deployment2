const voucherService = require('../../service/voucherService');
const ledgerService = require('../../service/ledgersService');
const messages = require('../../data/messages');

module.exports = function (router) {

  router.get('/voucher/:vType', (req, res, next) => {
    var user;
    ledgerService.getLedgers().then(function (result) {
      user = result;
      voucherService.getVourcherByVTypeAndVMode(req.params.vType).then(function (result) {

        var data = [];
        result.forEach(ele => {
          var sender = user.filter(function (els) {
            return els.code === ele.sender;
          })
          var receiver = user.filter(function (els) {
            return els.code === ele.receiver;
          })
          if (sender.length !== 0) {
            ele.sender = sender[0].ledgerName;
          }
          if (receiver.length !== 0) {
            ele.receiver = receiver[0].ledgerName;
          }

          data.push(ele);
        })
        res.send(data);
      });

    });
  });


  router.get('/voucher/resNo/:res', (req, res, next) => {

    voucherService.getVourcherByResNo(req.params.res).then(function (result) {
      res.json(result);
    });

  });

  router.get('/voucher/between/:ledgerId/:from/:to', (req, res, next) => {
    var user;
    ledgerService.getLedgers().then(function (result) {
      user = result;
      voucherService.getVourcherBetweenDates(req.params.ledgerId,
        req.params.from, req.params.to).then(function (vouchers) {

        var data = [];
        vouchers.forEach(ele => {
          var sender = user.filter(function (els) {
            return els.code === ele.sender;
          })
          var receiver = user.filter(function (els) {
            return els.code === ele.receiver;
          })
          if (sender.length !== 0) {
            ele.sender = sender[0].ledgerName;
          }
          if (receiver.length !== 0) {
            ele.receiver = receiver[0].ledgerName;
          }
          data.push(ele);
        })
        res.send(data);
      }).catch(error => {
        console.log(error);
      });
    });
  });

  router.get('/voucher/byId/:id', (req, res, next) => {

    voucherService.getVourcherById(req.params.id).then(function (result) {
      res.json(result);
    });

  });


  router.post('/voucher', (req, res, next) => {
    try {
      voucherService.saveVoucher(req.body);
    } catch (error) {
      res.status(500).send(messages.Failed());
    }

    res.status(200).send(messages.Success());

  });

  router.patch('/voucher', (req, res, next) => {
    try {
      voucherService.updateVoucher(req.body).then(response => {
        res.status(200).send(messages.Success());
      });
    } catch (error) {
      res.status(500).send(messages.Failed());
    }
  });

  router.patch('/voucher/resNo', (req, res, next) => {
    try {
      voucherService.updateVoucherByResNo(req.body);
    } catch (error) {
      res.status(500).send(messages.Failed());
    }

    res.status(200).send(messages.Success());

  });

  router.delete('/voucher/:resNo', (req, res, next) => {
    try {
      voucherService.deleteVoucherByResNo(req.params.resNo);
    } catch (error) {
      res.status(500).send(messages.Failed());
    }

    res.status(200).send(messages.Success());

  });

}
