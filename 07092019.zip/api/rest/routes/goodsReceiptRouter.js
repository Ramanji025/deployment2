const goodsReceiptService = require('../../service/goodsReceiptService');
const ledgerService = require('../../service/ledgersService');
const messages = require('../../data/messages');

module.exports = function (router) {

    router.get('/goods/receipt', (req, res, next) => {
        console.log("/goods/receipt get ***** Start");
        ledgerService.getLedgers().then(function (result) {
            var ledger = result;
            goodsReceiptService.getGoodsReceipt().then(function (goodsRes) {
                var data = [];
                goodsRes.forEach(ele => {
                    var sender = ledger.filter(function (els) {
                        return els.code === ele.vendor;
                    })

                    if (sender.length !== 0) {
                        ele.vendor = sender[0].ledgerName;
                    }

                    data.push(ele);
                })

                console.log("/goods/receipt get ***** Exit")
                res.json(data);
            });

        });
    });

  router.get('/goods/receipt/byFromAndTo/:from/:to', (req, res, next) => {
    console.log("/goods/receipt get ***** Start");
    ledgerService.getLedgers().then(function (result) {
      var ledger = result;
      goodsReceiptService.getGoodsReceiptByFromAndTo(req.params.from,req.params.to).then(function (goodsRes) {
        var data = [];
        goodsRes.forEach(ele => {
          var sender = ledger.filter(function (els) {
            return els.code === ele.vendor;
          })

          if (sender.length !== 0) {
            ele.vendor = sender[0].ledgerName;
          }

          data.push(ele);
        })

        console.log("/goods/receipt get ***** Exit")
        res.json(data);
      });

    });
  });


    router.get('/goods/receipt/:resNo', (req, res, next) => {
        console.log("/goods/receipt by resNo ***** Start");
        ledgerService.getLedgers().then(function (result) {
            var ledger = result;
            goodsReceiptService.getGoodsReceiptByResNo(req.params.resNo).then(function (goodsRes) {
                var data = [];
                goodsRes.forEach(ele => {
                    var sender = ledger.filter(function (els) {
                        return els.code === ele.vendor;
                    })

                    if (sender.length !== 0) {
                        ele.vendor = sender[0].ledgerName;
                    }

                    data.push(ele);
                })

                console.log("/goods/receipt by resNo ***** Exit")
                res.json(data);
            });

        });
    });

    router.get('/goods/receipt/raw/:resNo', (req, res, next) => {
        console.log("/goods/receipt/raw ***** Start");


        goodsReceiptService.getGoodsReceiptByResNo(req.params.resNo).then(function (goodsRes) {

            console.log("/goods/receipt/raw ***** Exit")
            res.json(goodsRes);
        });
    });

    router.get('/goods/receipt/byDate/today', (req, res, next) => {
        console.log("/goods/receipt/byDate ***** Start");
        goodsReceiptService.getGoodsReceiptCountByDate().then(function (goodsRes) {
        console.log("/goods/receipt/byDate ***** Exit")
            res.json(goodsRes);
        });
    });
   router.post('/goods/receipt', (req, res, next) => {
    try {
        console.log("/goods/receipt post *************** Start")
        goodsReceiptService.saveGoodsReceipt(req.body);
    } catch (error) {
        console.log(error);
        res.status(500).send(messages.Failed());
    }
    console.log("/goods/receipt Exit *************** Exit")
    res.status(200).send(messages.Success());

});

router.patch('/goods/receipt', (req, res, next) => {
    try {
        console.log("/goods/receipt patch *************** Start")
        goodsReceiptService.updateGoodsReceipt(req.body);
    } catch (error) {
        res.status(500).send(messages.Failed());
    }
    console.log("/goods/receipt patch *************** Exit")
    res.status(200).send(messages.Success());

});

router.delete('/goods/receipt/:id', (req, res, next) => {
    try {
        goodsReceiptService.deleteGoodsReceiptById(req.params.id);
    } catch (error) {
        res.status(500).send(messages.Failed());
    }
    res.status(200).send(messages.Success());

});


}
