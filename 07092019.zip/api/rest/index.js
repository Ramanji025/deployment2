const express = require('express')
const router = express.Router()

require('./routes/companyRouter')(router)
require('./routes/goodsItemRouter')(router)
require('./routes/goodsReceiptRouter')(router)
require('./routes/groupRouter')(router)
require('./routes/itemMasterRouter')(router)
require('./routes/ledgerRouter')(router)
require('./routes/usersRouter')(router)
require('./routes/voucherRouter')(router)
require('./routes/salesRouter')(router)

module.exports = router