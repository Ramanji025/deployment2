const mongoose = require('mongoose')

const UserSchema = new mongoose.Schema({
    userName : 'string',
    password :  'string',
    name : 'string',
    date: {type: 'date', default: new Date()},
    active: {type:'string',default:'Y'},
});

module.exports = mongoose.model( 'User', UserSchema )
