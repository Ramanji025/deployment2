const mongoose = require('mongoose');

const CompanySchema = new mongoose.Schema({
    company: 'string',
    contact: 'string',
    address: 'string'
});

module.exports = mongoose.model('Company',CompanySchema);