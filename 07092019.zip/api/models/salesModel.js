const mongoose = require('mongoose');

const GoodsSalesSchema = new mongoose.Schema({
    resNo: 'string',
    invoiceNo: 'string',
    invoiceDate: {type:'date'},
    vendor: 'string',
    active: {type:'string',default:'Y'},
    transCharges: 'number',
    approve: 'string'
});

module.exports = mongoose.model('GoodsSales',GoodsSalesSchema);