const mongoose = require('mongoose');

const VoucherSchema = new mongoose.Schema({
    voucherId : 'number',
    date : 'date',
    sender : 'string',
    receiver: 'string',
    amount: 'number',
    description: 'string',
    vType: 'string',
    vMode: 'string',
    active: {type:'string',default:'Y'},
    jLedger: 'string',
    resNo: 'string',
    cheque:{type:'string',default:'0'}
});

module.exports = mongoose.model('Voucher',VoucherSchema);
