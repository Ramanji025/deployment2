const mongoose = require('mongoose');

const GroupSchema = new mongoose.Schema({
    code:'string',
    groupName: 'string',
    date: {type: 'date', default: new Date()},
    active: {type:'string',default:'Y'},
});

module.exports = mongoose.model( 'Groups', GroupSchema )
